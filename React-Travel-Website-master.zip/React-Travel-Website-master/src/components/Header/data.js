export const navLinks = [
  {
    text: "Home",
    link: "home",
  },
  {
    text: "About",
    link: "about",
  },
  {
    text: "Discover",
    link: "discover",
  },
  {
    text: "Places",
    link: "places",
  },
];
