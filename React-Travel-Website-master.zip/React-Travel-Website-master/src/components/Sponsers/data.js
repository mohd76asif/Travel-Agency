import image1 from "../../assets/sponsors1.png";
import image2 from "../../assets/sponsors2.png";
import image3 from "../../assets/sponsors3.png";
import image4 from "../../assets/sponsors4.png";
import image5 from "../../assets/sponsors5.png";
// import image11 from "../../assets/sponsors1.jpg";

export const sponserss = [
  {
    image: image1,
  },
  {
    image: image2,
  },
  {
    image: image3,
  },
  {
    image: image4,
  },
  {
    image: image2,
  },
  {
    image: image5,
  },
];
