import image1 from "../../assets/about3.jpg";
import image2 from "../../assets/about4.jpg";

export const images = [
  {
    image: image1,
    classes: ["about__img-one"],
  },
  {
    image: image2,
    classes: ["about__img-two"],
  },
];
